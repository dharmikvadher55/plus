import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;

public class HelloServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        HttpSession session = req.getSession();
        String username = (String) session.getAttribute("username");

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        if (username == null) {
            session.setAttribute("username", "JohnDoe");
            out.println("<html><body><h2>New session created and username set to JohnDoe</h2></body></html>");
        } else {
            out.println("<html><body><h2>Welcome back, " + username + "!</h2></body></html>");
        }
        
        out.println("<html><body><a href='Read'>Invalidate Session</a></body></html>");
    }
}