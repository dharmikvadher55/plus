import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;

public class Read extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false); // false: don't create a new session if one doesn't exist
        String username = (session != null) ? (String) session.getAttribute("username") : null;

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        if (username != null) {
            out.println("<html><body><h2>Current session username: " + username + "</h2></body></html>");
        } else {
            out.println("<html><body><h2>No session attribute 'username' found.</h2></body></html>");
        }
        
      
    }
}